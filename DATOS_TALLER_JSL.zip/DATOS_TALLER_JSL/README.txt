ACCESO A LA DOCUMENTACIÓN DEL TALLER
====================================
* Para acceder al material del taller, debes abrir el documento index.html con un explorador web.

ACCESO A LOS DATOS UTILIZADOS EN EL TALLER
==========================================

Los datos para la realización de los diferentes ejercicios, así como para el seguimiento del taller se encuentran en el fichero DATOS_TALLER_JSL.zip

La fuente de los datos utilizados para este taller son:

* El contenido de la carpeta 3D proviene del Institut Cartogràfic i Geològic de Catalunya.
* El contenido de la carpeta DG_CATASTRO_LA_VAJOL, proviene de la Dirección General del Catastro de España
* El contenido de la carpeta DATOS_MESH, ha sido directamente descargado en QGIS mediante el complemento GRIB Downloader.
* El contenido de la carpeta FOTOS_GEOTAGGED, es de elaboración propia.
* El contenido de la carpeta MAPILLARY, proviene del propio proyecto de Mapillary (usr: xevi).
* El fichero Building_scale_adjusting_measurements.qml ha sido elaborado por Michel Stuyts y Klas Karlsson: https://gitlab.com/GIS-projects/qgis-geometry-generator-examples


Todo el material del taller se publica bajo licencia CC-BY-SA: Ferran Orduña, Lluís Vicens (SIGTE - Univesitat de Girona), Jornadas de SIG Libre 2019

Girona, 10/06/2019

----------------
